<div class="p-10">
   <div class="mb-5">
        <h3 class="font-bold text-3xl text-gray-800 my-3">
                <?php echo e($vacante->titulo); ?>

        </h3>

        <div class="md:grid md:grid-cols-2 bg-gray-50 p-4 my-10">
            <p class="font-bold text-sm uppercase text-gray-800 my-3"> Empresa:
                <span class="normal-case font-normal"> <?php echo e($vacante->empresa); ?> </span>
            </p>

            <p class="font-bold text-sm uppercase text-gray-800 my-3"> Último día para echar CV:
                <span class="normal-case font-normal"> <?php echo e($vacante->ultimo_dia->toFormattedDateString()); ?> </span>
            </p>

            <p class="font-bold text-sm uppercase text-gray-800 my-3"> Categoría:
                <span class="normal-case font-normal"> <?php echo e($vacante->categoria->categoria); ?> </span>
            </p>

            <p class="font-bold text-sm uppercase text-gray-800 my-3"> Salario:
                <span class="normal-case font-normal"> <?php echo e($vacante->salario->salario); ?> </span>
            </p>
        </div>
   </div>

<!-- gap te da la separación entre columnas -->
   
<div class="md:grid md:grid-cols-6 gap-4">

        <div class="md:col-span-2">
            <img src="<?php echo e(asset('storage/vacantes/' . $vacante->imagen )); ?>" alt="<?php echo e('Imagen vacante' . $vacante->titulo); ?>">
        </div>

        <div class="md:col-span-4">
            <h2 class="text-2xl font-bold mb-5"> Descripción del Puesto</h2>
            <p><?php echo e($vacante->descripcion); ?></p>
        </div>

    </div>
<?php if(auth()->guard()->guest()): ?>
    <div class="mt-5 bg-gray-50 border border-dashed p-5 text-center">
        <p>
            ¿Deseas inscribirte a esta vacante? <a class="font-bold text-indigo-600" href="<?php echo e(route('register')); ?>"> 
                Obten una cuenta e inscribete a esta y otras vacantes</a>
        </p>
    </div>
<?php endif; ?>

<!-- Actúa como un if , Si el usuario no puede crear vacante o si-->

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('create', App\Models\Vacante::class)): ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('postular-vacante', ['vacante' => $vacante])->html();
} elseif ($_instance->childHasBeenRendered('l3155686769-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l3155686769-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3155686769-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3155686769-0');
} else {
    $response = \Livewire\Livewire::mount('postular-vacante', ['vacante' => $vacante]);
    $html = $response->html();
    $_instance->logRenderedChild('l3155686769-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php endif; ?>

</div>
<?php /**PATH C:\Users\Desiree\Desktop\proyecto-devjobs\resources\views/livewire/muestra-vacante.blade.php ENDPATH**/ ?>