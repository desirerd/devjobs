<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Candidatos Vacante')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <h1 class="text-2xl font-bold text-center my-10"> Candidatos Vacante : <?php echo e($vacante->titulo); ?>

                    </h1>

                    <div class="md:flex md:justify-center p-5">
                        <ul class="divide-y divide-gray-200 w-full">
                            <?php $__empty_1 = true; $__currentLoopData = $vacante->candidatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <li class="p-3 flex items-center">
                                    <div class="flex-1">
                                        <p class="text-xl font-medium text-gray-800">
                                            <?php echo e($candidato->user->name); ?>

                                        </p>
                                        <p class="text-sm text-gray-600">
                                            <?php echo e($candidato->user->email); ?>

                                        </p>
                                        <p class="textsm font-medium text-gray-600">
                                            Día que se postuló: <span class="font-normal"><?php echo e($candidato->created_at->diffForHumans()); ?>

                                        </span>
                                    </p>

                                    </div>
                                    
                                        <a class="inline-flex items-center shadow-sm px-2.5 py-0.5 border border-gray-300 text-sm 
                                            leading-5 font-medium rounded-full text-gray-700 bg-white hover:bg-gray-50" 
                                            href="<?php echo e(asset('storage/cv/' . $candidato->cv)); ?>"
                                            target="_blank"
                                            rel="noreferrer noopener">
                                            Ver CV
                                            
                                        </a>
                                    <div>

                                    </div>

                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="p-3 text-center text-sm text-gray-600"> No hay candidatos aún</p>
                            <?php endif; ?>
                        </ul>
                    </div>
                    
                 </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Desiree\Desktop\proyecto-devjobs\resources\views/candidatos/index.blade.php ENDPATH**/ ?>