
<?php
    
    $classes = "text-sm text-gray-600 hover:text-gray-900 
    rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2
     focus:ring-indigo-500"
?>

<!-- Le pasamos como atributo el href desde login.blade , Va a unir los atributos que recibe, pero el de la clase
del enlace, lo obtiene de la variable $classes -->

    <a <?php echo e($attributes->merge(['class' => $classes])); ?>>
        <?php echo e($slot); ?>

    </a>
<?php /**PATH C:\Users\Desiree\Desktop\proyecto-devjobs\resources\views/components/link.blade.php ENDPATH**/ ?>