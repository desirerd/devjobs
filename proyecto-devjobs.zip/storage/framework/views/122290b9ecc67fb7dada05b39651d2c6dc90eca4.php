<?php echo e($slot); ?>

<?php /**PATH C:\Users\Desiree\Desktop\proyecto-devjobs\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>