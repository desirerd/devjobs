<div class="border border-red-500 bd-red-100 text-red-700 font-bold uppercase p-2 mt-2 text-xs">
    <p><?php echo e($message); ?></p>
</div>
<?php /**PATH C:\Users\Desiree\Desktop\proyecto-devjobs\resources\views/livewire/mostrar-alerta.blade.php ENDPATH**/ ?>