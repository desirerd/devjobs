<h1 class="text-4xl">
    Dev<span class="font-extrabold">Jobs</span>
</h1>