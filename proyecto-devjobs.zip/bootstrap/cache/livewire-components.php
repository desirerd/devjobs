<?php return array (
  'crear-vacante' => 'App\\Http\\Livewire\\CrearVacante',
  'editar-vacante' => 'App\\Http\\Livewire\\EditarVacante',
  'filtrar-vacantes' => 'App\\Http\\Livewire\\FiltrarVacantes',
  'home-vacantes' => 'App\\Http\\Livewire\\HomeVacantes',
  'mostrar-alerta' => 'App\\Http\\Livewire\\MostrarAlerta',
  'mostrar-vacante' => 'App\\Http\\Livewire\\MostrarVacante',
  'muestra-vacante' => 'App\\Http\\Livewire\\MuestraVacante',
  'postular-vacante' => 'App\\Http\\Livewire\\PostularVacante',
);